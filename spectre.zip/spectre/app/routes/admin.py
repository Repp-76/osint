"""
app/routes/admin.py
-------------------
Admin panel routes: CRUD for categories and resources,
JSON import/export, and dashboard.

No authentication is implemented in this educational build —
add Flask-Login or HTTP Basic Auth before any public deployment.
"""

import json
from flask import (Blueprint, render_template, request, jsonify,
                   redirect, url_for, flash, current_app)
from ..database import get_db
from ..utils.validators import validate_resource, validate_category
from .. import accounts as acc

admin_bp = Blueprint("admin", __name__)


# ── Helpers ────────────────────────────────────────────────────────────────────

def _row(row):
    return dict(row) if row else None


def _all_categories_flat(db):
    """Return all categories as a flat list ordered for a <select> element."""
    return db.execute(
        "SELECT id, name, parent_id, sort_order FROM categories ORDER BY sort_order, name"
    ).fetchall()


# ── Dashboard ──────────────────────────────────────────────────────────────────

@admin_bp.route("/")
def dashboard():
    db = get_db()
    stats = {
        "total_resources":  db.execute("SELECT COUNT(*) FROM resources").fetchone()[0],
        "active_resources": db.execute("SELECT COUNT(*) FROM resources WHERE status='active'").fetchone()[0],
        "total_categories": db.execute("SELECT COUNT(*) FROM categories").fetchone()[0],
        "total_clicks":     db.execute("SELECT COUNT(*) FROM usage_log").fetchone()[0],
    }
    recent = db.execute("""
        SELECT r.id, r.name, r.description, r.url, r.tags, r.status,
               r.free, r.requires_account, r.added_at, c.name as cat_name
        FROM resources r JOIN categories c ON c.id = r.category_id
        ORDER BY r.added_at DESC LIMIT 10
    """).fetchall()
    return render_template("admin/dashboard.html", stats=stats,
                           recent=[_row(r) for r in recent])


# ── Resources ──────────────────────────────────────────────────────────────────

@admin_bp.route("/resources")
def list_resources():
    db   = get_db()
    page = max(1, int(request.args.get("page", 1)))
    per  = 25
    offset = (page - 1) * per
    total = db.execute("SELECT COUNT(*) FROM resources").fetchone()[0]
    rows  = db.execute("""
        SELECT r.id, r.name, r.description, r.url, r.tags, r.status, r.free,
               r.requires_account, r.added_at, c.name as cat_name
        FROM resources r JOIN categories c ON c.id = r.category_id
        ORDER BY r.added_at DESC LIMIT ? OFFSET ?
    """, (per, offset)).fetchall()
    return render_template("admin/resources.html",
                           resources=[_row(r) for r in rows],
                           page=page, total=total, per=per)


@admin_bp.route("/resources/new", methods=["GET", "POST"])
def new_resource():
    db = get_db()
    if request.method == "POST":
        ok, data, errors = validate_resource(request.form)
        if not ok:
            return render_template("admin/resource_form.html",
                                   categories=_all_categories_flat(db),
                                   errors=errors, form=request.form)
        db.execute("""
            INSERT INTO resources (name,description,url,category_id,tags,status,free,requires_account)
            VALUES (:name,:description,:url,:category_id,:tags,:status,:free,:requires_account)
        """, data)
        db.commit()
        current_app.logger.info(f"Admin: created resource '{data['name']}'")
        return redirect(url_for("admin.list_resources"))

    return render_template("admin/resource_form.html",
                           categories=_all_categories_flat(db),
                           errors=[], form={})


@admin_bp.route("/resources/<int:rid>/edit", methods=["GET", "POST"])
def edit_resource(rid):
    db  = get_db()
    row = db.execute("SELECT * FROM resources WHERE id=?", (rid,)).fetchone()
    if not row:
        return "Resource not found", 404

    if request.method == "POST":
        ok, data, errors = validate_resource(request.form)
        if not ok:
            return render_template("admin/resource_form.html",
                                   categories=_all_categories_flat(db),
                                   errors=errors, form=request.form, resource=_row(row))
        db.execute("""
            UPDATE resources
            SET name=:name, description=:description, url=:url, category_id=:category_id,
                tags=:tags, status=:status, free=:free, requires_account=:requires_account,
                updated_at=CURRENT_TIMESTAMP
            WHERE id=:id
        """, {**data, "id": rid})
        db.commit()
        current_app.logger.info(f"Admin: updated resource id={rid}")
        return redirect(url_for("admin.list_resources"))

    resource = _row(row)
    resource["tags"] = json.loads(resource.get("tags") or "[]")
    return render_template("admin/resource_form.html",
                           categories=_all_categories_flat(db),
                           errors=[], form=resource, resource=resource)


@admin_bp.route("/resources/<int:rid>/delete", methods=["POST"])
def delete_resource(rid):
    db = get_db()
    row = db.execute("SELECT name FROM resources WHERE id=?", (rid,)).fetchone()
    if not row:
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return jsonify({"ok": False, "error": "Not found"}), 404
        return redirect(url_for("admin.list_resources"))

    name = row["name"]
    db.execute("DELETE FROM resources WHERE id=?", (rid,))
    db.commit()
    current_app.logger.info(f"Admin: deleted resource \'{name}\' (id={rid})")

    # AJAX request from popup
    if request.headers.get("X-Requested-With") == "XMLHttpRequest":
        return jsonify({"ok": True, "deleted": name})

    return redirect(url_for("admin.list_resources"))


# ── Categories ─────────────────────────────────────────────────────────────────

@admin_bp.route("/categories")
def list_categories():
    db   = get_db()
    rows = db.execute("""
        SELECT c.id, c.name, c.slug, c.icon, c.sort_order,
               p.name as parent_name,
               COUNT(r.id) as resource_count
        FROM categories c
        LEFT JOIN categories p ON p.id = c.parent_id
        LEFT JOIN resources  r ON r.category_id = c.id
        GROUP BY c.id ORDER BY c.sort_order, c.name
    """).fetchall()
    return render_template("admin/categories.html",
                           categories=[_row(r) for r in rows])


@admin_bp.route("/categories/new", methods=["GET", "POST"])
def new_category():
    db = get_db()
    if request.method == "POST":
        ok, data, errors = validate_category(request.form)
        if not ok:
            return render_template("admin/category_form.html",
                                   all_cats=_all_categories_flat(db),
                                   errors=errors, form=request.form)
        # Enforce slug uniqueness
        existing = db.execute("SELECT id FROM categories WHERE slug=?", (data["slug"],)).fetchone()
        if existing:
            return render_template("admin/category_form.html",
                                   all_cats=_all_categories_flat(db),
                                   errors=["A category with this slug already exists."],
                                   form=request.form)
        db.execute("""
            INSERT INTO categories (name,slug,description,parent_id,icon,sort_order)
            VALUES (:name,:slug,:description,:parent_id,:icon,:sort_order)
        """, data)
        db.commit()
        current_app.logger.info(f"Admin: created category '{data['name']}'")
        return redirect(url_for("admin.list_categories"))

    return render_template("admin/category_form.html",
                           all_cats=_all_categories_flat(db),
                           errors=[], form={})


@admin_bp.route("/categories/<int:cid>/edit", methods=["GET", "POST"])
def edit_category(cid):
    db  = get_db()
    row = db.execute("SELECT * FROM categories WHERE id=?", (cid,)).fetchone()
    if not row:
        return "Category not found", 404

    if request.method == "POST":
        ok, data, errors = validate_category(request.form)
        if not ok:
            return render_template("admin/category_form.html",
                                   all_cats=_all_categories_flat(db),
                                   errors=errors, form=request.form, category=_row(row))
        # Check slug uniqueness (exclude self)
        existing = db.execute(
            "SELECT id FROM categories WHERE slug=? AND id!=?", (data["slug"], cid)
        ).fetchone()
        if existing:
            return render_template("admin/category_form.html",
                                   all_cats=_all_categories_flat(db),
                                   errors=["A category with this slug already exists."],
                                   form=request.form, category=_row(row))
        # Prevent self-parenting
        if data.get("parent_id") == cid:
            data["parent_id"] = None

        db.execute("""
            UPDATE categories
            SET name=:name, slug=:slug, description=:description,
                parent_id=:parent_id, icon=:icon, sort_order=:sort_order
            WHERE id=:id
        """, {**data, "id": cid})
        db.commit()
        current_app.logger.info(f"Admin: updated category id={cid}")
        return redirect(url_for("admin.list_categories"))

    return render_template("admin/category_form.html",
                           all_cats=_all_categories_flat(db),
                           errors=[], form=_row(row), category=_row(row))


@admin_bp.route("/categories/<int:cid>/delete", methods=["POST"])
def delete_category(cid):
    db = get_db()
    db.execute("DELETE FROM categories WHERE id=?", (cid,))
    db.commit()
    current_app.logger.info(f"Admin: deleted category id={cid}")
    return redirect(url_for("admin.list_categories"))


# ── JSON Import / Export ───────────────────────────────────────────────────────

@admin_bp.route("/import", methods=["GET", "POST"])
def import_json():
    db = get_db()
    if request.method == "POST":
        try:
            file = request.files.get("json_file")
            raw  = file.read() if file else request.form.get("json_data", "")
            payload = json.loads(raw)
        except Exception as e:
            return render_template("admin/import.html", error=f"Invalid JSON: {e}")

        imported_cats = 0
        imported_res  = 0
        errors        = []

        # Import categories first (respect parent relationships)
        for cat in payload.get("categories", []):
            try:
                ok, data, errs = validate_category(cat)
                if not ok:
                    errors.append(f"Category '{cat.get('name')}': {', '.join(errs)}")
                    continue
                existing = db.execute(
                    "SELECT id FROM categories WHERE slug=?", (data["slug"],)
                ).fetchone()
                if not existing:
                    db.execute("""
                        INSERT INTO categories (name,slug,description,parent_id,icon,sort_order)
                        VALUES (:name,:slug,:description,:parent_id,:icon,:sort_order)
                    """, data)
                    imported_cats += 1
            except Exception as e:
                errors.append(f"Category error: {e}")

        db.commit()

        # Import resources
        for res in payload.get("resources", []):
            try:
                ok, data, errs = validate_resource(res)
                if not ok:
                    errors.append(f"Resource '{res.get('name')}': {', '.join(errs)}")
                    continue
                db.execute("""
                    INSERT INTO resources (name,description,url,category_id,tags,status,free,requires_account)
                    VALUES (:name,:description,:url,:category_id,:tags,:status,:free,:requires_account)
                """, data)
                imported_res += 1
            except Exception as e:
                errors.append(f"Resource error: {e}")

        db.commit()
        current_app.logger.info(
            f"Admin import: {imported_cats} categories, {imported_res} resources."
        )
        return render_template("admin/import.html",
                               success=True,
                               imported_cats=imported_cats,
                               imported_res=imported_res,
                               errors=errors)

    return render_template("admin/import.html")


# ── Account Management (login system for the public portal) ─────────────────
# Accounts are created via the Telegram bot (/create username,password[,dur]).
# This panel manages existing accounts: view, search, sort, extend duration,
# reset device binding, and remove.

@admin_bp.route("/accounts")
def list_accounts():
    db = get_db()
    search = request.args.get("q", "").strip() or None
    sort = request.args.get("sort", "created")
    rows = acc.list_accounts(db, search=search, sort=sort)

    account_list = []
    for r in rows:
        d = dict(r)
        d["is_expired"] = acc.is_expired(r)
        d["remaining"] = acc.remaining_label(r)
        account_list.append(d)

    stats = acc.get_stats(db)

    return render_template(
        "admin/accounts.html",
        accounts=account_list,
        stats=stats,
        search=search or "",
        sort=sort,
    )


@admin_bp.route("/accounts/<int:aid>/remove", methods=["POST"])
def remove_account(aid):
    db = get_db()
    row = acc.get_account_by_id(db, aid)
    if not row:
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return jsonify({"ok": False, "error": "Not found"}), 404
        return redirect(url_for("admin.list_accounts"))

    username = row["username"]
    acc.remove_account(db, aid)
    current_app.logger.info(f"Admin: removed account '{username}' (id={aid})")

    if request.headers.get("X-Requested-With") == "XMLHttpRequest":
        return jsonify({"ok": True, "removed": username})
    return redirect(url_for("admin.list_accounts"))


@admin_bp.route("/accounts/<int:aid>/add-duration", methods=["POST"])
def add_account_duration(aid):
    db = get_db()
    token = request.form.get("duration", "").strip() or None
    try:
        acc.add_duration(db, aid, token)
    except acc.AccountError as e:
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return jsonify({"ok": False, "error": str(e)}), 400
        return redirect(url_for("admin.list_accounts"))
    except acc.DurationError as e:
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return jsonify({"ok": False, "error": str(e)}), 400
        return redirect(url_for("admin.list_accounts"))

    current_app.logger.info(f"Admin: extended account id={aid} by '{token}'")
    if request.headers.get("X-Requested-With") == "XMLHttpRequest":
        row = acc.get_account_by_id(db, aid)
        return jsonify({"ok": True, "remaining": acc.remaining_label(row)})
    return redirect(url_for("admin.list_accounts"))


@admin_bp.route("/accounts/<int:aid>/reset-device", methods=["POST"])
def reset_account_device(aid):
    db = get_db()
    acc.reset_device(db, aid)
    current_app.logger.info(f"Admin: reset device binding for account id={aid}")
    if request.headers.get("X-Requested-With") == "XMLHttpRequest":
        return jsonify({"ok": True})
    return redirect(url_for("admin.list_accounts"))


@admin_bp.route("/accounts/new", methods=["POST"])
def new_account():
    """Fallback manual account creation from the admin panel (accounts are
    normally created via the Telegram bot)."""
    db = get_db()
    username = request.form.get("username", "").strip()
    password = request.form.get("password", "").strip()
    duration = request.form.get("duration", "").strip() or None
    try:
        acc.create_account(db, username, password, duration)
        current_app.logger.info(f"Admin: created account '{username}'")
    except (acc.AccountError, acc.DurationError) as e:
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return jsonify({"ok": False, "error": str(e)}), 400
    if request.headers.get("X-Requested-With") == "XMLHttpRequest":
        return jsonify({"ok": True})
    return redirect(url_for("admin.list_accounts"))


@admin_bp.route("/telegram-config", methods=["POST"])
def save_telegram_config():
    db = get_db()
    acc.set_config(db, "bot_token", request.form.get("bot_token", "").strip())
    acc.set_config(db, "admin_id", request.form.get("admin_id", "").strip())
    current_app.logger.info("Admin: updated Telegram bot configuration")
    return redirect(url_for("admin.list_accounts"))


@admin_bp.route("/accounts/stats")
def accounts_stats_json():
    """Lightweight JSON endpoint the accounts page polls for realtime stats
    without a full page reload."""
    db = get_db()
    return jsonify(acc.get_stats(db))


# ── Device Info (standalone page, reached via the red "Device Info" button
# next to "Add Resource") ────────────────────────────────────────────────
# Shows just the device name for every account that has logged in at
# least once. Click a name to open a scrollable popup with the full
# account + device detail — same data as the Account page's Info popup.

@admin_bp.route("/device-info")
def device_info():
    db = get_db()
    rows = acc.list_accounts(db, search=None, sort="username")
    devices = []
    for r in rows:
        if not r["device_id"]:
            continue
        d = dict(r)
        d["is_expired"] = acc.is_expired(r)
        d["remaining"] = acc.remaining_label(r)
        devices.append(d)
    return render_template("admin/device_info.html", devices=devices)


@admin_bp.route("/accounts/<int:aid>/toggle-lock", methods=["POST"])
def toggle_account_lock(aid):
    db = get_db()
    row = acc.get_account_by_id(db, aid)
    if not row:
        if request.headers.get("X-Requested-With") == "XMLHttpRequest":
            return jsonify({"ok": False, "error": "Not found"}), 404
        return redirect(url_for("admin.device_info"))

    new_state = not acc.is_locked(row)
    acc.set_locked(db, aid, new_state)
    current_app.logger.info(
        f"Admin: {'locked' if new_state else 'unlocked'} account '{row['username']}' (id={aid})"
    )

    if request.headers.get("X-Requested-With") == "XMLHttpRequest":
        return jsonify({"ok": True, "locked": new_state})
    return redirect(url_for("admin.device_info"))
