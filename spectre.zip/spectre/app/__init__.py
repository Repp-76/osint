"""
app/__init__.py
---------------
Application factory for SPECTRE OSINT Platform.
Creates TWO separate Flask apps:
  - public_app  → serves portal only (no admin routes)
  - admin_app   → serves admin panel only, IP-restricted
"""

import os
import logging
from logging.handlers import RotatingFileHandler
from flask import Flask, g, request, abort
from .database import init_db, get_db


# ── Shared config ──────────────────────────────────────────────────────────────

def _base_config(app):
    app.config["SECRET_KEY"] = os.environ.get(
        "SECRET_KEY", "CHANGE_THIS_IN_PRODUCTION_" + os.urandom(16).hex()
    )
    app.config["DATABASE"] = os.path.join(
        os.path.dirname(os.path.dirname(__file__)), "data", "spectre.db"
    )
    app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024


def _setup_logging(app, logfile="spectre.log"):
    logs_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "logs")
    os.makedirs(logs_dir, exist_ok=True)
    handler = RotatingFileHandler(
        os.path.join(logs_dir, logfile), maxBytes=1_000_000, backupCount=5
    )
    handler.setFormatter(logging.Formatter(
        "[%(asctime)s] %(levelname)s in %(module)s: %(message)s"
    ))
    app.logger.addHandler(handler)
    app.logger.setLevel(logging.INFO)


def _security_headers(app):
    @app.after_request
    def _headers(response):
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"]         = "DENY"
        response.headers["X-XSS-Protection"]        = "1; mode=block"
        response.headers["Referrer-Policy"]          = "strict-origin-when-cross-origin"
        response.headers["Content-Security-Policy"]  = (
            "default-src 'self'; "
            "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
            "font-src 'self' https://fonts.gstatic.com; "
            "script-src 'self' 'unsafe-inline'; "
            "img-src 'self' data:; "
            "connect-src 'self';"
        )
        return response


def _db_teardown(app):
    @app.teardown_appcontext
    def close_db(error):
        db = g.pop("db", None)
        if db is not None:
            db.close()


# ── IP lock (Telegram /lock, /unlock) ───────────────────────────────────────
# Blocks a specific IP from BOTH the public portal and the admin panel,
# independent of any account/session. Checked first, before any other
# access logic, on every request except static files.

def _ip_lock_guard(app):
    from . import ip_locks as _ip_locks
    from flask import render_template

    @app.before_request
    def _check_ip_lock():
        if request.path.startswith("/static/"):
            return None

        client_ip = request.headers.get("CF-Connecting-IP") or request.remote_addr or ""
        db = get_db(app)
        if _ip_locks.is_ip_locked(db, client_ip):
            return render_template(
                "locked.html",
                message="Your device and IP have been locked by Repp76. "
                        "Please contact Telegram @Repp76 to unlock it."
            ), 403


# ── IP allowlist for admin ─────────────────────────────────────────────────────

# Read allowed IPs from env or use defaults.
# Set ADMIN_ALLOWED_IPS="192.168.1.10,10.0.0.5" to customise.
# "127.0.0.1" and "::1" (localhost) are always allowed.
_DEFAULT_ADMIN_IPS = {"127.0.0.1", "::1", "localhost"}


def _get_admin_allowed_ips():
    env_ips = os.environ.get("ADMIN_ALLOWED_IPS", "")
    extra   = {ip.strip() for ip in env_ips.split(",") if ip.strip()}
    return _DEFAULT_ADMIN_IPS | extra


def _admin_ip_guard(app):
    """Block requests whose remote IP is not in the allowlist.

    When using cloudflared tunnel (cloudflared tunnel --url http://localhost:8089),
    all tunnel traffic arrives at Flask with remote_addr=127.0.0.1 (localhost),
    which is always in the allowlist — so tunnel users with the link can access.
    X-Forwarded-For is NOT used for the access check to avoid blocking tunnel
    traffic; it is only logged for reference.
    """
    allowed = _get_admin_allowed_ips()

    @app.before_request
    def _check_ip():
        # Use remote_addr directly — cloudflared tunnel connects from 127.0.0.1
        # so tunnel access is allowed without needing to whitelist external IPs.
        client_ip = request.remote_addr

        if client_ip not in allowed:
            # Log the real IP from Cloudflare header if available
            cf_ip = request.headers.get("CF-Connecting-IP", "")
            forwarded = request.headers.get("X-Forwarded-For", "")
            app.logger.warning(
                f"Admin access DENIED for IP {client_ip} "
                f"(CF-Connecting-IP={cf_ip}, X-Forwarded-For={forwarded}) "
                f"→ {request.path}"
            )
            abort(403)


# ── Public app factory ────────────────────────────────────────────────────────

def create_public_app():
    """
    Public portal — serves the OSINT portal and read-only API.
    Runs on 0.0.0.0:8980. No admin routes.
    """
    app = Flask(
        __name__,
        template_folder="../templates",
        static_folder="../static"
    )
    _base_config(app)
    _setup_logging(app, "public.log")

    with app.app_context():
        init_db(app)

    _db_teardown(app)
    _security_headers(app)
    _ip_lock_guard(app)


    # ── Jinja2 custom filters ──────────────────────────────────────────────────
    import json as _json
    @app.template_filter('fromjson')
    def _fromjson(s):
        try:
            return _json.loads(s) if s else []
        except Exception:
            return []

    from .routes.main import main_bp
    from .routes.api  import api_bp

    app.register_blueprint(main_bp)
    app.register_blueprint(api_bp, url_prefix="/api")

    # ── Login system (public portal only — admin panel is untouched) ────────
    from .auth import auth_bp, install_login_gate
    app.register_blueprint(auth_bp)
    install_login_gate(app)
    _start_account_ticker(app)

    app.logger.info("SPECTRE public portal initialised.")
    return app


# ── Pausable account countdown ─────────────────────────────────────────────
# Timed accounts only lose time while a backend process is alive and
# ticking (see app/accounts.py). This starts that engine once per Python
# process: resume immediately (swallow any downtime since the last run),
# then tick on an interval for as long as the process stays up.

_ticker_started = False


def _start_account_ticker(app, interval_seconds=15):
    global _ticker_started
    if _ticker_started:
        return
    _ticker_started = True

    import threading
    import time as _time
    from . import accounts as _accounts
    from . import roles as _roles

    def _loop():
        with app.app_context():
            db = get_db(app)
            _accounts.resume_accounts(db)
            _roles.resume_roles(db)
        while True:
            _time.sleep(interval_seconds)
            try:
                with app.app_context():
                    db = get_db(app)
                    _accounts.tick_accounts(db)
                    _roles.tick_roles(db)
            except Exception:
                app.logger.exception("Account ticker error")

    threading.Thread(target=_loop, daemon=True, name="spectre-account-ticker").start()


# ── Admin app factory ─────────────────────────────────────────────────────────

def create_admin_app():
    """
    Admin panel — IP-restricted, serves only the admin dashboard.
    Runs on 0.0.0.0:8089. Only configured IPs can connect.
    """
    app = Flask(
        __name__,
        template_folder="../templates",
        static_folder="../static"
    )
    _base_config(app)
    _setup_logging(app, "admin.log")

    with app.app_context():
        init_db(app)

    _db_teardown(app)
    _security_headers(app)
    _ip_lock_guard(app)
    _admin_ip_guard(app)


    # ── Jinja2 custom filters ──────────────────────────────────────────────────
    import json as _json
    @app.template_filter('fromjson')
    def _fromjson(s):
        try:
            return _json.loads(s) if s else []
        except Exception:
            return []

    from .routes.admin import admin_bp
    from .routes.api   import api_bp   # Admin also needs API for export

    app.register_blueprint(admin_bp, url_prefix="/admin")
    app.register_blueprint(api_bp,   url_prefix="/api")

    # Redirect root to /admin/
    from flask import redirect, url_for

    @app.route("/")
    def admin_root():
        return redirect("/admin/")

    app.logger.info("SPECTRE admin panel initialised.")
    return app


# ── Legacy single-app factory (kept for test compatibility) ──────────────────

def create_app():
    """Single-app mode — used by unit tests only."""
    app = Flask(
        __name__,
        template_folder="../templates",
        static_folder="../static"
    )
    _base_config(app)
    _setup_logging(app)

    with app.app_context():
        init_db(app)

    _db_teardown(app)
    _security_headers(app)


    # ── Jinja2 custom filters ──────────────────────────────────────────────────
    import json as _json
    @app.template_filter('fromjson')
    def _fromjson(s):
        try:
            return _json.loads(s) if s else []
        except Exception:
            return []

    from .routes.main  import main_bp
    from .routes.api   import api_bp
    from .routes.admin import admin_bp

    app.register_blueprint(main_bp)
    app.register_blueprint(api_bp,   url_prefix="/api")
    app.register_blueprint(admin_bp, url_prefix="/admin")

    app.logger.info("SPECTRE single-app mode initialised.")
    return app
