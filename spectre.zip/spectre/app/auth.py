"""
app/auth.py
-----------
Login system for the SPECTRE public portal (port 8980 only — the
admin panel on 8089 is untouched and still IP-restricted only).

- Username/password accounts, created exclusively via the Telegram bot
  or the admin "Account" panel.
- "Login once": a long-lived cookie (10 years) carries a session_token
  that is validated against the accounts table on every request — no
  in-memory session store, so it survives server/Termux/cloudflared
  restarts.
- 1 account = 1 device: the first successful login binds the account
  to the browser fingerprint (device_fingerprint) computed from stable
  navigator/screen values. This is the field actually compared on
  login. Future logins from a different fingerprint are rejected until
  an admin uses "Reset Device".

  device_id (the random UUID cached in localStorage) is still stored
  alongside it for admin display only — it is no longer used for the
  same-device check. localStorage is scoped per origin, so a new
  Cloudflare Tunnel URL after a restart wipes it and a fresh random
  device_id gets generated, which used to look like "another device"
  even though it's the same phone/browser. The fingerprint doesn't
  have that problem: it's recomputed fresh from navigator.userAgent /
  platform / screen / timezone every time, so it comes out identical
  regardless of which URL served the page.

Note on device binding: this is the strongest binding achievable from
a pure client-side web app (no native app / OS-level hooks). A user
who deliberately clears localStorage *and* cookies on the same
physical device will look like a "new device" to the server. Combine
with the fingerprint check to reduce (not eliminate) that gap.

Note on the session cookie itself surviving a tunnel URL change: it
can't. Cookies are bound to the origin that set them, so a brand new
trycloudflare.com URL never receives the old cookie — true zero-relogin
persistence needs the tunnel hostname to stay fixed (a named/persistent
Cloudflare Tunnel instead of `--url`). What this file guarantees is that
when the same device *does* log in again after the URL changes, it's
recognized as the same device instead of being falsely rejected.
"""

import secrets
from flask import Blueprint, render_template, request, redirect, url_for, g

from .database import get_db
from . import accounts as acc

auth_bp = Blueprint("auth", __name__)

SESSION_COOKIE = "spectre_sess"
COOKIE_MAX_AGE = 60 * 60 * 24 * 365 * 10  # 10 years


def _collect_device_meta(form):
    return {
        "device_name": form.get("device_name", "")[:120],
        "os": form.get("device_os", "")[:80],
        "browser": form.get("device_browser", "")[:80],
        "platform": form.get("device_platform", "")[:80],
        "timezone": form.get("device_timezone", "")[:60],
        "language": form.get("device_language", "")[:40],
        "screen": form.get("device_screen", "")[:40],
    }


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        return render_template("login.html", error=None)

    username = request.form.get("username", "").strip()
    password = request.form.get("password", "")
    device_id = request.form.get("device_id", "").strip()
    fingerprint = request.form.get("fingerprint", "").strip()

    db = get_db()
    row = acc.get_account_by_username(db, username)

    if not row or not acc.check_password(row, password):
        return render_template("login.html", error="Username atau password salah."), 401

    if acc.is_expired(row):
        return render_template("login.html", error="Akaun ini telah tamat tempoh."), 403

    if not device_id or not fingerprint:
        return render_template(
            "login.html",
            error="Tidak dapat mengesan device. Sila aktifkan JavaScript dan cuba lagi."
        ), 400

    # Same-device check now keys off the fingerprint, not device_id — see
    # the module docstring for why (device_id resets on every new tunnel URL).
    bound_fingerprint = row["device_fingerprint"]
    if bound_fingerprint and bound_fingerprint != fingerprint:
        return render_template(
            "login.html",
            error="Akaun ini telah digunakan pada device lain. Hubungi admin untuk Reset Device."
        ), 403

    session_token = secrets.token_hex(32)
    meta = _collect_device_meta(request.form)
    ip = request.headers.get("CF-Connecting-IP") or request.remote_addr or ""
    acc.bind_device(
        db, row["id"], device_id, fingerprint, session_token,
        meta=meta, user_agent=request.headers.get("User-Agent", ""), ip=ip
    )

    resp = redirect(url_for("main.index"))
    resp.set_cookie(
        SESSION_COOKIE, session_token,
        max_age=COOKIE_MAX_AGE, httponly=True, samesite="Lax"
    )
    return resp


@auth_bp.route("/logout", methods=["GET", "POST"])
def logout():
    db = get_db()
    token = request.cookies.get(SESSION_COOKIE)
    row = acc.get_account_by_session(db, token) if token else None
    if row:
        acc.clear_session(db, row["id"])
    resp = redirect(url_for("auth.login"))
    resp.delete_cookie(SESSION_COOKIE)
    return resp


def install_login_gate(app):
    """Attach a before_request gate to the given Flask app that requires a
    valid, non-expired session cookie for every route except /login,
    /logout, and static files. Call only on the PUBLIC app — never on
    the admin app."""

    @app.before_request
    def _require_login():
        path = request.path
        if path.startswith("/static/") or path in ("/login", "/logout"):
            return None

        db = get_db()
        token = request.cookies.get(SESSION_COOKIE)
        row = acc.get_account_by_session(db, token) if token else None

        if not row:
            return redirect(url_for("auth.login"))

        if acc.is_expired(row):
            # Auto-logout: wipe the session so the device must sign back
            # in once the account is renewed by an admin.
            acc.clear_session(db, row["id"])
            resp = redirect(url_for("auth.login"))
            resp.delete_cookie(SESSION_COOKIE)
            return resp

        if acc.is_locked(row):
            # Locked accounts stay "logged in" (session/device binding is
            # left untouched) but see only the lock screen on every page
            # until an admin unlocks them — this persists across restarts
            # since it's a plain DB flag, not tied to the session.
            return render_template("locked.html"), 403

        acc.touch_last_active(db, row["id"])
        g.current_account = row
        return None
